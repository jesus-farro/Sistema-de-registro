<h1>Sistema de Registro</h1>

- Estado del proyecto: En construcción.

Para ejecutar:

```npm install react```
